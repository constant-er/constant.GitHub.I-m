package com.cloud.justyou.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public class IndexMapper {
}
