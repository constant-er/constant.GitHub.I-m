package com.cloud.justyou;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JustYouApplication {

    public static void main(String[] args) {
        SpringApplication.run(JustYouApplication.class, args);
    }

}
