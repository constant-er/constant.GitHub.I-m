package com.cloud.justyou.service;

public interface IndexService {
}
