package com.cloud.justyou.service.impl;

import com.cloud.justyou.service.IndexService;
import org.springframework.stereotype.Service;

@Service
public class IndexServiceImpl implements IndexService {
}
