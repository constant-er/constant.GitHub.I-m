package com.cloud.justyou.controller.fore;

import org.springframework.stereotype.Controller;

/**
 * @author HP
 */
@Controller
public class IndexController {



}
